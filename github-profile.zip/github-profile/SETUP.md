# How to put this on your GitHub profile

1. On GitHub, create a **new public repository named exactly `KanungoShubham`** (same as your username). GitHub shows its README on your profile page.
2. Upload everything in this folder to the root of that repo:
   - `README.md`
   - `hero.svg`, `about.svg`, `stack.svg`, `id-dashboard.svg`, `journey.svg`, `connect.svg`
   - `.github/workflows/profile-3d.yml` (keep the folder path)
   - optional: `build_svgs.py` + `assets/avatar.jpg` (to regenerate the cards)
3. Open the **Actions** tab → *GitHub Profile 3D Contrib* → **Run workflow** once. It creates the `profile-3d-contrib/` folder for the contribution city, then refreshes daily.
4. Visit https://github.com/KanungoShubham — done.

## Editing the cards
All text lives in `build_svgs.py`. Change it, then run `python3 build_svgs.py` to rebuild the SVGs.
After uploading new versions, bump `?v=1` → `?v=2` in README.md so GitHub's image cache refreshes.
